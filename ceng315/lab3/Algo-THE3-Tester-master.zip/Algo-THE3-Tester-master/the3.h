#include <iostream>
#include <vector>
#include <random>
#include <ctime>
#include <algorithm>
#include <cassert>
#include <climits>
int Important (int n, int**& edgeList, double*& scores);
