#ifndef _LAB_1_H_
#define _LAB_1_H_

#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>

int search(std::vector<int>& nums, int num);

void sort(std::vector<int>& nums);

int odd(std::vector<int>& nums);

#endif