#include "lab1.h"


int skyline(std::vector<std::vector<int>>& grid){
  
  
}


int search(std::vector<int>& array, int num){


}
