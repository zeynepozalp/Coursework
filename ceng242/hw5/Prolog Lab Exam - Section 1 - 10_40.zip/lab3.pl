:- module(lab3, [similar_distributions/2, proton_ionization/3]).
:- [catoms].

% DO NOT CHANGE THE UPPER CONTENT, WRITE YOUR CODE AFTER THIS LINE